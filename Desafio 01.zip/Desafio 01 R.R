library(base)

basecsv <- read.csv('flights.csv')
basecsv <- read.csv(file.choose())

library(readr)

readrcsv <- read_csv('flights.csv')
readrcsv <- read_csv(file.choose())



